# AVR Migration Inventory Script <br/>
This is a modified version of the mig_av script. It is for creating ingest sheets for works that have been migrated from AVR.
